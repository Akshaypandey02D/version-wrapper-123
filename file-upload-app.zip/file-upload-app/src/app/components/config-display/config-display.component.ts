import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import {
  trigger,
  style,
  transition,
  animate,
} from '@angular/animations';

import { UploadInstallerService } from '../../services/upload-installer.service';
import { LoaderComponent } from '../loader/loader.component';

@Component({
  selector: 'app-config-display',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, LoaderComponent],
  templateUrl: './config-display.component.html',
  styleUrl: './config-display.component.css',
  animations: [
    trigger('fadeSlide', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(16px)' }),
        animate('300ms ease-out', style({ opacity: 1, transform: 'translateY(0)' })),
      ]),
      transition(':leave', [
        animate('200ms ease-in', style({ opacity: 0, transform: 'translateY(-16px)' })),
      ]),
    ]),
  ],
  providers: [UploadInstallerService],
})
export class ConfigDisplayComponent {
  appForm!: FormGroup;

  // Step control: 'upload' -> 'config' -> 'submit'
  currentStep: 'upload' | 'config' | 'submit' = 'upload';

  // File upload info
  uploadedFileName: string = '';
  uploadedFileType: 'msi' | 'exe' = 'msi';
  isLoader: boolean = false;

  // Template version selector
  selectedVersion: 'v1' | 'v2' = 'v1';

  // Templates for different versions and file types
  scriptTemplates = {
    v1: {
      msi: {
        install: "Execute-MSI -Action 'Install' -Path 'epasetup.msi",
        uninstall: 'Start-Process msiexec.exe -ArgumentList "/x app.msi /qn"',
        repair: 'Start-Process msiexec.exe -ArgumentList "/fa app.msi /qn"',
      },
      exe: {
        install: 'Start-Process "app.exe" -ArgumentList "/S"',
        uninstall: 'Remove-Item "C:\\Program Files\\App"',
        repair: 'Start-Process "app.exe" -ArgumentList "/repair"',
      },
    },
    v2: {
      msi: {
        install: 'msiexec /i "app.msi" /quiet',
        uninstall: 'msiexec /x "app.msi" /quiet',
        repair: 'msiexec /fa "app.msi" /quiet',
      },
      exe: {
        install: 'Start-Process "app_v2.exe" -ArgumentList "/silent"',
        uninstall: 'Uninstall-App -Name "AppName"',
        repair: 'Repair-App -Name "AppName"',
      },
    },
  };

  constructor(
    private fb: FormBuilder,
    private uploadInstallerService: UploadInstallerService
  ) {}

  ngOnInit(): void {
    // Initialize form with defaults
    this.appForm = this.fb.group({
      appName: ['', Validators.required],
      appVersion: ['', Validators.required],
      publisher: ['', Validators.required],
      publisherEmail: ['', [Validators.required, Validators.email]],
      msiName: ['',Validators.required],
      description: [''], // optional
      installScript: ['', Validators.required],
      uninstallScript: ['', Validators.required],
      repairScript: ['', Validators.required],
    });
  }

  // Called when form is submitted
  onSubmit(): void {
    console.log(this.appForm.value);
    this.currentStep = 'submit';
    this.uploadInstallerService.postAppDetails(this.appForm).subscribe({
      next: (response:any) => {
        
      },
      error: (error:any) => {
        console.error('Error occurred:', error);
      },
    });
  }

  // Go back to upload step
  routeToStart(): void {
    this.currentStep = 'upload';
  }

  // Triggered when a file is selected
  handleFileUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    console.log('Selected file:', file.name);
    this.uploadedFileType = file.name.endsWith('.msi') ? 'msi' : 'exe';
    this.uploadMsiFile(file, file.name);
  }

  // Uploads the file and moves to config step
  uploadMsiFile(file: File, fileUploadedName: string): void {
    this.isLoader = true;

    this.uploadInstallerService.uploadMsiFile(file).subscribe(
      (response: any) => {
        this.isLoader = false;
        this.currentStep = 'config';
        this.updateScriptTemplates(); // Auto-fill scripts
        console.log('Server response:', response.output);
        const versionInfo = response?.fileInfo?.versionInfo;

        if (versionInfo) {
          this.appForm.patchValue({
            appName: versionInfo.ProductName || '',
            appVersion: versionInfo.ProductVersion || '',
            publisher: versionInfo.Manufacturer || '',
            msiName:fileUploadedName
            
           
          });
        }
      },
      (error: any) => {
        this.isLoader = false;
        this.currentStep = 'config';
        console.error('Upload failed:', error);
        // TODO: Show a proper error message to user (e.g., toast/alert)
      }
    );
  }

  // Auto-fill install/uninstall/repair scripts based on selected version and file type
  updateScriptTemplates(): void {
    const templates = this.scriptTemplates[this.selectedVersion][this.uploadedFileType];

    this.appForm.patchValue({
      installScript: templates.install,
      uninstallScript: templates.uninstall,
      repairScript: templates.repair,
    });
  }
}
