import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpEvent } from '@angular/common/http';
import { catchError, map, Observable, throwError } from 'rxjs';
import { environment } from '../../enviroments/environment'; // 👈 import env

@Injectable({
  providedIn: 'root',
})
export class UploadInstallerService {
  private baseUrl = environment.apiBaseUrl; // 👈 use env var
  public authToken = ''; // Token needs to be set from somewhere

  constructor(private http: HttpClient) {}

  // Headers including Bearer token
  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      Authorization: `Bearer ${this.authToken}`,
    });
  }

  public uploadMsiFile(data: File): Observable<HttpEvent<any>> {
    const formData = new FormData();
    formData.append('file', data);

    return this.http.post<any>(this.baseUrl, formData, {
      headers: this.getHeaders(),
      reportProgress: true,
      observe: 'events', // In case you want progress updates
    }).pipe(
      map((response: any) => {
        if (response) return response;
        throw response;
      }),
      catchError((error) => throwError(() => error))
    );
  }

  private apiUrl = 'https://useapp55824.mhf.mhc/api/v2/workflow_job_templates/28/launch/'; // Base API URL
  private authTokens = '47VMoCUfyXtLZhGA3FBKVrQTOOFQXZ'; 


  public postAppDetails( data:any): Observable<any> {
    const payload = {
      extra_vars: {
          appname: data.name || '',          
          appversion: data.version || '',     
          appvendor: data.publisher || '',   
          authname: data.name || 'Default',  
          description: data.description || '', 
          email_id: data.author || '',        
          disp_name: data["display name"] || '' ,
          repair_block:data.repair_block || '',
          uninstall_block:data.uninstall_block || '',
          install_block:data.install_block ||'',
      }
  };


    const headers = new HttpHeaders({
      Authorization: `Bearer ${this.authTokens}`, 
      'Content-Type': 'application/json', 
    });

    return this.http.post(this.apiUrl, payload, { headers }).pipe(
      catchError((error) => {
        console.error('Error occurred:', error);
        return throwError(() => error);
      })
    );
  }
}
