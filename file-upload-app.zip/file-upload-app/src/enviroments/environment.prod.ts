export const environment = {
    production: false,
    apiBaseUrl: 'https://dev.packagebuilder.mhf.mhc/api/upload/',
  };