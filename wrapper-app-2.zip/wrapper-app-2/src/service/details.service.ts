import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private apiUrl = 'https://useapp55824.mhf.mhc/api/v2/workflow_job_templates/28/launch/'; // Base API URL
  private authToken = '47VMoCUfyXtLZhGA3FBKVrQTOOFQXZ'; 

  constructor(private http: HttpClient) {}

  /**
   * Sends a POST request with the specified payload to the API, including the auth token in the headers.
   * @returns An Observable of the response.
   */
  public postAppDetails( data:any): Observable<any> {
    const payload = {
      extra_vars: {
          appname: data.name || '',          
          appversion: data.version || '',     
          appvendor: data.publisher || '',   
          authname: data.name || 'Default',  
          description: data.description || '', 
          email_id: data.author || '',        
          disp_name: data["display name"] || '' ,
          repair_block:data.repair_block || '',
          uninstall_block:data.uninstall_block || '',
          install_block:data.install_block ||'',
      }
  };


    const headers = new HttpHeaders({
      Authorization: `Bearer ${this.authToken}`, 
      'Content-Type': 'application/json', 
    });

    return this.http.post(this.apiUrl, payload, { headers }).pipe(
      catchError((error) => {
        console.error('Error occurred:', error);
        return throwError(() => error);
      })
    );
  }
}
