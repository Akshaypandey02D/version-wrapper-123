import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GeneralComponent } from './pages/general/general.component';
import { MainActionsComponent } from './pages/main-actions/main-actions.component';
import { PreActionsComponent } from './pages/pre-actions/pre-actions.component';
import { PostActionsComponent } from './pages/post-actions/post-actions.component';
import { UpgradeComponent } from './pages/upgrade/upgrade.component';
import { ScriptEditorComponent } from './pages/script-editor/script-editor.component';
import { ConfigurationComponent } from './pages/configuration/configuration.component';

export const routes: Routes = [
  { path: '', redirectTo: 'general', pathMatch: 'full' },
  { path: 'general', component: GeneralComponent },
  { path: 'main-actions', component: MainActionsComponent },
  { path: 'pre-actions', component: PreActionsComponent },
  { path: 'post-actions', component: PostActionsComponent },
  { path: 'upgrade', component: UpgradeComponent },
  { path: 'script-editor', component: ScriptEditorComponent },
  { path: 'configuration', component: ConfigurationComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
