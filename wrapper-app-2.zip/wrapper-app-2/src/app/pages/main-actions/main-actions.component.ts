import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-main-actions',
  imports: [CommonModule ],
  templateUrl: './main-actions.component.html',
  styleUrl: './main-actions.component.scss'
})
export class MainActionsComponent {
  public sections = [
    { title: 'Install', description: 'Actions performed during installation' },
    { title: 'Uninstall', description: 'Actions performed during uninstallation' },
    { title: 'Repair', description: 'Actions performed during repair' },
  ];

  handleAddInstaller(sectionTitle: string) {
    alert(`${sectionTitle} installer added`);
  }
}
