import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreActionsComponent } from './pre-actions.component';

describe('PreActionsComponent', () => {
  let component: PreActionsComponent;
  let fixture: ComponentFixture<PreActionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PreActionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreActionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
