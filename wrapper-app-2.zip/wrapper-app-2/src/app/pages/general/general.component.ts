import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeploymentSectionComponent } from "./deployment-section/deployment-section.component";
import { PackageDetectionSectionComponent } from "./package-detection-section/package-detection-section.component";
import { AdditionalInfoSectionComponent } from "./additional-info-section/additional-info-section.component";
import { FormBuilder, FormGroup,FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ApiService } from '../../../service/details.service';
import { MainActionsComponent } from "../main-actions/main-actions.component";


interface Field {
  label: string;
  key: string;
  value: string;
}


type Result = {
  install_block?: string;
  uninstall_block?: string;
  repair_block?: string;
};

@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.scss'],
  imports: [ReactiveFormsModule, CommonModule,FormsModule],
  providers:[ApiService]
})
export class GeneralComponent {
 
  public isModalOpen = false;
  public editForm!: FormGroup;

  fields:any = [
    { label: 'Name', key: 'name', value: 'Gaurav' },
    { label: 'Version', key: 'version', value: '1.1' },
    { label: 'Publisher', key: 'publisher', value: 'S&P' },
    { label: 'Architecture', key: 'architecture', value: 'x86' },
    { label: 'Msi Name', key: 'display name', value: 'Vs.MSI' },
    { label: 'Author', key: 'author', value: 'gaurav.dhyani2@spglobal.com' },
    { label: 'Description', key: 'description', value: 'This is demo' },
  ];

  public deploymentConfig = {
    suppressReboot: true,
    terminalServerMode: false,
    installationMode: 'Interactive'
  };

 
  public sections= [
    { title: 'Install', description: 'Actions performed during installation', details: '' },
    { title: 'Uninstall', description: 'Actions performed during uninstallation', details: '' },
    { title: 'Repair', description: 'Actions performed during repair', details: '' },
  ];
 

  public packageDetectionType = 'Registry';

  public notes: string = 'this is demo';

  informationUrl: string = '';

  constructor(private fb: FormBuilder,private apiService:ApiService ) {
    // Initialize the form with properly typed values
    this.editForm = this.fb.group(
      this.fields.reduce((formControls: { [x: string]: any[]; }, field: { key: string | number; value: any; }) => {
        formControls[field.key] = [field.value]; // Initialize each control
        return formControls;
      }, {})
    );
  }

  onNotesUpdated(newNotes: string) {
    this.notes = newNotes;
  }

  onUrlUpdated(newUrl: string) {
    this.informationUrl = newUrl;
  }

  openEditModal() {
    this.isModalOpen = true;
    const patchValues = this.fields.reduce((values: { [x: string]: any; }, field: { key: string | number; value: any; }) => {
      values[field.key] = field.value;
      return values;
    }, {});
    this.editForm.patchValue(patchValues);
  }

  closeEditModal() {
    this.isModalOpen = false;
  }

  submitForm(){
      this.apiService.postAppDetails(this.editForm.value).subscribe({
        next: (response) => {
          console.log('API Response:', response);
        },
        error: (error) => {
          console.error('Error:', error);
        },
      });
    }

  handleAddInstaller(sectionTitle: string) {
      alert(`${sectionTitle} installer added`);
  }

  submitData(){
    const result: Result = this.sections.reduce((acc, item) => {
      acc[`${item.title.toLowerCase()}_block` as keyof Result] = item.details;
      return acc;
    }, {} as Result);
    var mergedObject = { ...result, ...this.editForm.value };
    this.apiService.postAppDetails( mergedObject).subscribe({
      next: (response) => {
        console.log('API Response:', response);
      },
      error: (error) => {
        console.error('Error:', error);
      },
    });
    
 
  }
  
}
  