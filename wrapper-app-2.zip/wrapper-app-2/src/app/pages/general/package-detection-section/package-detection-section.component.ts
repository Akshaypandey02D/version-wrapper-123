import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-package-detection-section',
  templateUrl: './package-detection-section.component.html',
  styleUrls: ['./package-detection-section.component.scss']
})
export class PackageDetectionSectionComponent {
  @Input() detectionType!: string;
}
