import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-deployment-section',
  templateUrl: './deployment-section.component.html',
  styleUrls: ['./deployment-section.component.scss']
})
export class DeploymentSectionComponent {
  @Input() deploymentConfig!: any;
}
