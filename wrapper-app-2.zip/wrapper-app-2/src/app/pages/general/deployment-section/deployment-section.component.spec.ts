import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeploymentSectionComponent } from './deployment-section.component';

describe('DeploymentSectionComponent', () => {
  let component: DeploymentSectionComponent;
  let fixture: ComponentFixture<DeploymentSectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeploymentSectionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeploymentSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
