import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  imports:[CommonModule]
})
export class SidebarComponent {
  isCollapsed = false;

  constructor(private router: Router) {} 
  
  toggleSidebar() {
    this.isCollapsed = !this.isCollapsed;
  }

  navigateTo(route: string) {
    this.router.navigate([route]).then(() => {
      console.log('Navigation successful:', route);
    }).catch(err => {
      console.error('Navigation failed:', err);
    });
  }
}
